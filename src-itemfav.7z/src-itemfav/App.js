import React, {Component} from 'react';
import ItemsButton from './ItemsButton';
import Item from './Item.js';
import OnClickOutside from './OnClickOutside.js';

class App extends Component {
  constructor(props){
    super(props)

      let items = [];
      for(let i=1;i<=50;i++){
        items.push({
          name: i,
          price: Math.floor(Math.random()*100),
          id: Math.random()*Math.pow(10,17),
          isFavorite: false,
        });
      }

      this.state = {
        openMenuId: '',
        favorites: [],
        cart: [],
        items: items
      }
  }

  handleToggle = (id)=>{
    this.setState({openMenuId: id?id:''})
  }

  addToFav = (item)=>{
      console.log(item)
      const i = Object.assign({}, item);
      const index = this.state.favorites.map(
                      (el)=>el.id).findIndex((el)=>el===i.id);

      index === -1 
        ? this.setState({favorites: [...this.state.favorites, item]})
        : this.setState({favorites: this.state.favorites.filter(
            (el)=>el.id !== item.id)});
  }

  addToCart = (item)=>{ 
      const cartId = Math.random()*Math.pow(10,17);
      let i = Object.assign({}, item);
      i.id = cartId;
      console.log(i);
      this.setState({cart: [...this.state.cart, i]})
  }

  removeFromCart = (item)=>{
      console.log(item);
      const index = this.state.cart.map(
                      (el)=>el.id).findIndex((el)=>el===item.id);
      console.log(index);

      index !== -1 
        && this.setState({cart: this.state.cart.filter(
            (el)=>el.id !== item.id)});

  }

  render(){
    return (
    <div className="app" onClick={()=>{return this.handleToggle('')}}>
      <div className="top-bar clearfix">
          <h1 className="title left">Shopping Cart</h1>
          <OnClickOutside action={this.handleToggle}>
          <ItemsButton  name={this.state.cart.length>0
                              ?"Корзина "+this.state.cart.length
                              :"Корзина"} 
                        className={this.state.cart.length>0
                                  ?"btn-active"
                                  :""} 
            openId={this.state.openMenuId}
            toggle={this.handleToggle}
            list={this.state.cart}
            removeAction={this.removeFromCart}/>
          <ItemsButton name="Избранное" 
            openId={this.state.openMenuId}
            toggle={this.handleToggle}
            list={this.state.favorites}
            removeAction={this.addToFav}/>
          </OnClickOutside>
      </div>
      <div className="content">
        {this.state.items.map(item=>{return (
            <Item key={item.id}
                  id={item.id}
                  name={item.name}
                  price={item.price} 
                  actionCart={this.addToCart} 
                  actionFav={this.addToFav} 
                  isFavorite={this.state.favorites
                                .map(el=>el.id)
                                .find(el=>el===item.id)}/>
          )}

        )}
      </div>
    </div>
  );
  }
}

export default App;
