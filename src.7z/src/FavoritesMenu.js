import React, {Component} from 'react';

class FavoritesMenu extends Component {
	render(){

		return(
				<div className="fav-menu clearfix">
					{this.props.list &&
						this.props.list.map(item=>{
						return(
							<div key={item.id} className="sel-items left">
								<div className="sel-item-img">
									<div className="sel-item-title">
										{item.name}
									</div>
									{item.price}$
									<div className="rem-button"
										onClick={(e)=>{e.stopPropagation();this.props.removeAction(item)}}>
										Remove
									</div>
								</div>
							</div>
						)
					})}
				</div>
			);
	}
}

export default FavoritesMenu;